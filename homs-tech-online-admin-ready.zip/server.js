
const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const { Pool } = require("pg");

const app = express();
app.use(express.json({limit:"1mb"}));
app.use(cookieParser());

const PORT = process.env.PORT || 3000;
const DATABASE_URL = process.env.DATABASE_URL;
const JWT_SECRET = process.env.JWT_SECRET;
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;

if (!DATABASE_URL || DATABASE_URL.includes("PASTE_") || !JWT_SECRET || !ADMIN_PASSWORD) {
  console.warn("Missing DATABASE_URL, JWT_SECRET, or ADMIN_PASSWORD environment variable.");
}

const pool = new Pool({
  connectionString: DATABASE_URL,
  ssl: DATABASE_URL && !/localhost|127\.0\.0\.1/.test(DATABASE_URL) ? {rejectUnauthorized:false} : false
});

const defaults = {
  businessName:"HOMS TECH",
  tagline:"تصليح هواتف عند باب بيتك",
  heroTitle:"موبايلك خربان؟ نحن منجي لعندك! 🚗📱",
  heroText:"تصليح جميع أنواع الهواتف عند باب بيتك — خدمة سريعة، شغل نظيف وأسعار مناسبة.",
  whatsapp:"31612345678",
  phone:"+31 6 12345678",
  areas:"Rotterdam والمناطق القريبة",
  services:[
    ["🖥️","تبديل الشاشات","شاشة مكسورة أو لا تعمل؟"],
    ["🔋","تبديل البطاريات","بطارية ضعيفة أو تفرغ بسرعة؟"],
    ["🔌","أعطال الشحن","الجهاز لا يشحن أو يفصل؟"],
    ["⚙️","هاردوير وسوفتوير","تشخيص وإصلاح مختلف الأعطال."]
  ],
  why:[
    ["⚡","سريع","نحاول ننجز التصليح بأسرع وقت ممكن."],
    ["🛠️","احترافي","تشخيص دقيق وشغل مرتب."],
    ["🚗","نجي لعندك","خدمة متنقلة بدل ما تتعب وتطلع."],
    ["💰","سعر مناسب","اسألنا عن السعر قبل التصليح."]
  ],
  phones:[
    12,13,14,15,16,17
  ].map(m=>({name:`iPhone ${m}`,brand:"Apple",screen:"",software:"",hardware:"",camera:""}))
};

async function initDb(){
  await pool.query(`
    CREATE TABLE IF NOT EXISTS site_settings (
      id INTEGER PRIMARY KEY,
      data JSONB NOT NULL,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )
  `);
  const r = await pool.query("SELECT id FROM site_settings WHERE id=1");
  if (!r.rowCount) {
    await pool.query("INSERT INTO site_settings(id,data) VALUES(1,$1)", [JSON.stringify(defaults)]);
  }
}
async function getData(){
  const r = await pool.query("SELECT data FROM site_settings WHERE id=1");
  return r.rows[0]?.data || defaults;
}
function auth(req,res,next){
  try{
    const token=req.cookies.homs_admin;
    if(!token) return res.status(401).json({error:"غير مسجل الدخول"});
    jwt.verify(token,JWT_SECRET);
    next();
  }catch(e){return res.status(401).json({error:"انتهت جلسة الدخول"});}
}
function cleanData(d){
  const out={...defaults,...d};
  for(const k of ["services","why","phones"]) if(!Array.isArray(out[k])) out[k]=defaults[k];
  return out;
}

app.get("/api/site", async (req,res)=>{
  try{res.json(await getData())}catch(e){res.status(500).json({error:"تعذر تحميل البيانات"})}
});
app.post("/api/login", async (req,res)=>{
  const {username,password}=req.body||{};
  const ok=username===ADMIN_USERNAME && ADMIN_PASSWORD && await bcrypt.compare(password, await bcrypt.hash(ADMIN_PASSWORD,10));
  if(!ok) return res.status(401).json({error:"اسم المستخدم أو كلمة السر غير صحيحة"});
  const token=jwt.sign({sub:"admin"},JWT_SECRET,{expiresIn:"7d"});
  res.cookie("homs_admin",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:7*24*60*60*1000});
  res.json({ok:true});
});
app.post("/api/logout",(req,res)=>{res.clearCookie("homs_admin");res.json({ok:true})});
app.get("/api/me",auth,(req,res)=>res.json({ok:true}));
app.put("/api/site",auth,async(req,res)=>{
  try{
    const data=cleanData(req.body);
    await pool.query("UPDATE site_settings SET data=$1,updated_at=NOW() WHERE id=1",[JSON.stringify(data)]);
    res.json({ok:true,data});
  }catch(e){console.error(e);res.status(500).json({error:"تعذر حفظ التعديلات"})}
});

app.use(express.static(path.join(__dirname,"public")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));

initDb().then(()=>app.listen(PORT,()=>console.log(`HOMS TECH running on ${PORT}`)))
.catch(e=>{console.error("Database initialization failed",e);process.exit(1)});
