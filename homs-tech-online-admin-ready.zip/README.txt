HOMS TECH - لوحة تحكم حقيقية تعمل من أي جهاز

هذه النسخة تستخدم:
- Node.js + Express
- PostgreSQL لحفظ البيانات على الإنترنت
- تسجيل دخول للوحة التحكم
- أسعار الأجهزة والخدمات تُحفظ على السيرفر، وليس داخل المتصفح

الصفحات:
/
/about.html
/repair.html
/devices.html
/prices.html
/admin/

النشر:
1. أنشئ قاعدة PostgreSQL (مثلاً Neon أو Supabase أو قاعدة PostgreSQL لدى الاستضافة).
2. انسخ DATABASE_URL إلى متغير البيئة.
3. عيّن ADMIN_USERNAME و ADMIN_PASSWORD و JWT_SECRET.
4. شغّل:
   npm install
   npm start

مهم:
- غيّر كلمة سر admin قبل النشر.
- لا تضع DATABASE_URL أو JWT_SECRET داخل ملفات الموقع.
